<?php
  header('Content-Type:text/html;charset=UTF-8');
?>
<div class="container">
  <p>
    <a href="javascript:;">慕课简介 </a>|
    <a href="javascript:;">慕课公告 </a>|
    <a href="javascript:;">招纳贤士 </a>|
    <a href="javascript:;">联系我们 </a>|
    <span>客服热线：400-675-1234</span>
  </p>
  <p>Copyright &copy; 2006 - 2014 慕课版权所有&nbsp;&nbsp;&nbsp;京ICP备09037834号&nbsp;&nbsp;&nbsp;京ICP证B1034-8373号&nbsp;&nbsp;&nbsp;某市公安局XX分局备案编号：123456789123 </p>
  <p class="brand">
    <img src="image/pic/foot_img.jpg" alt=""/>
    <img src="image/pic/foot_img.jpg" alt=""/>
    <img src="image/pic/foot_img.jpg" alt=""/>
    <img src="image/pic/foot_img.jpg" alt=""/>
  </p>
</div>